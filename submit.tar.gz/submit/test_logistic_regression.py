import pickle as pkl
import numpy as np
from sklearn.metrics import roc_auc_score, average_precision_score

x_train = np.load('X_train_logistic.npy')
y_train = np.load('y_train.npy')
x_test = np.load('X_test_logistic.npy')
y_test = np.load('y_test.npy')

lr = pkl.load(open('logistic.pkl', 'rb'))

# Train Score
y_score = lr.predict_proba(x_train)
train_auroc = roc_auc_score(y_train, y_score[:, 1])
train_auprc = average_precision_score(y_train, y_score[:, 1])

# Test Score
y_score = lr.predict_proba(x_test)
test_auroc = roc_auc_score(y_test, y_score[:, 1])
test_auprc = average_precision_score(y_test, y_score[:, 1])

with open('[STUDENT_ID]_logistic_regression.txt', 'w') as f:
    f.write('[STUDENT_ID]\n')
    f.write(str(train_auroc) + "\n")
    f.write(str(train_auprc) + "\n")
    f.write(str(test_auroc) + "\n")
    f.write(str(test_auprc) + "\n")