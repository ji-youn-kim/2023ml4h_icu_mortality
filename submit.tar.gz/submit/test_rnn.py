import pandas as pd

import torch
import torch.nn as nn

from torch.utils.data import DataLoader
from sklearn.metrics import roc_auc_score, average_precision_score


class EHRDataset(nn.Module):
    def __init__(self, split):

        self.split = split
        if self.split == 'train':
            data = pd.read_pickle('X_train_rnn.pkl')
        else:
            data = pd.read_pickle('X_test_rnn.pkl')
        self.data = list(data.values())

    def __len__(self):
        return len(self.data)

    def collator(self, samples):
        x_cat = [s["x_cat"] for s in samples]
        x_cont = [s["x_cont"] for s in samples]
        s_len = [len(s["x_cat"]) for s in samples]
        labels = [s["label"] for s in samples]

        x_cat = nn.utils.rnn.pad_sequence(x_cat, batch_first=True) #(B, S, F_c)
        x_cont = nn.utils.rnn.pad_sequence(x_cont, batch_first=True) #(B, S, F_n)

        batch_input = {"x_cat": x_cat, #(B, S, #cat_features)
            "x_cont": x_cont, #(B, S, #num_features)
            "s_len": s_len}
        
        return {
            "input": batch_input,
            "labels": labels
        }


    def __getitem__(self, index):
        pack = {
            "x_cat": torch.tensor([[self.data[index]["ADMISSION_TYPE"], self.data[index]["ADMISSION_LOCATION"], self.data[index]["DIAGNOSIS"], i[1]] for i in self.data[index]["CHARTEVENTS"]]), #(S, #features)
            "x_cont": torch.tensor([[i[0], i[2]] for i in self.data[index]["CHARTEVENTS"]]),
            "label": self.data[index]["LABEL"]
        }
        return pack


class EHRRNN(nn.Module):
    def __init__(self, embed_dim=128, hidden_dim=256, num_layers=2, n_class=2):
        super().__init__()

        # Embedding Order: ADMISSION_TYPE, ADMISSION_LOCATION, DIAGNOSIS, ITEMID
        self.embedding_sizes = [6, 11, 4816, 1116]
        self.embeddings = nn.ModuleList([nn.Embedding(categories, embed_dim, padding_idx=0) for categories in self.embedding_sizes])

        input_size = embed_dim * len(self.embedding_sizes) + 2
        self.gru = nn.GRU(input_size, hidden_dim, num_layers, batch_first=True) 
        
        self.proj1 = nn.Linear(hidden_dim, hidden_dim // 2) 
        self.proj2 = nn.Linear(hidden_dim // 2, hidden_dim // 4) 
        self.final = nn.Linear(hidden_dim // 4, n_class) 


    def forward(self, x_cat, x_cont, s_len):

        # x_cat shape: (B, S, #features)
        B,S,F = x_cat.shape
        x1 = [e(x_cat[:, :, i]) for i, e in enumerate(self.embeddings)] # (B, S, emb) * #features
        x1 = torch.cat(x1, 2) # (B, S, #features*emb)
        # Concat categorical / numerical columns
        x = torch.cat([x1, x_cont], 2) # (B, S, #features_cat*emb + #features_cont)
        x = nn.utils.rnn.pack_padded_sequence(x, batch_first=True, lengths=s_len, enforce_sorted=False)
        
        output, _ = self.gru(x.float()) 
        output, _ = nn.utils.rnn.pad_packed_sequence(output, batch_first=True) # output: (B, S, h_out)

        # Mean pooling & Project Output
        output = torch.mean(output, 1) # (B, h_out)
        output = self.proj1(output)
        output = self.proj2(output)
        output = self.final(output) # (B, n_class)

        return output

gpu = 4
device = torch.device(f"cuda:{gpu}" if torch.cuda.is_available() else "cpu")

datasets, dataloader = dict(), dict()
datasets["train"] = EHRDataset('train')
datasets["test"] = EHRDataset('test')
dataloader["train"] = DataLoader(datasets["train"], collate_fn=datasets["train"].collator, num_workers=8, batch_size=1024, shuffle=True)
dataloader["test"] = DataLoader(datasets["test"], collate_fn=datasets["test"].collator, num_workers=8, batch_size=1024, shuffle=True)

model = EHRRNN()
model.load_state_dict(torch.load('rnn.pt'))
model.to(device)

criterion = nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(model.parameters(), lr=5e-3)

model.eval()

y_true_train, y_true_test, y_score_train, y_score_test = [], [], [], []
    
with torch.no_grad():

    for split in ["train", "test"]:
        for step, sample in enumerate(dataloader[split]):

            for key in sample["input"]:
                if key != "s_len":
                    sample["input"][key] = sample["input"][key].to(device)
            
            output = model(**sample["input"])
            loss = criterion(output, torch.tensor(sample["labels"]).to(device))

            probs = nn.functional.softmax(output, dim=-1).cpu().detach()
            if split == 'train':
                y_true_train.extend(sample["labels"])
                y_score_train.extend(probs[:, 1].tolist())
            else:
                y_true_test.extend(sample["labels"])
                y_score_test.extend(probs[:, 1].tolist())

    train_auroc = roc_auc_score(y_true_train, y_score_train)
    train_auprc = average_precision_score(y_true_train, y_score_train)
    test_auroc = roc_auc_score(y_true_test, y_score_test)
    test_auprc = average_precision_score(y_true_test, y_score_test)

    with open('[STUDENT_ID]_rnn.txt', 'w') as f:
        f.write('[STUDENT_ID]\n')
        f.write(str(train_auroc) + "\n")
        f.write(str(train_auprc) + "\n")
        f.write(str(test_auroc) + "\n")
        f.write(str(test_auprc) + "\n")
        
